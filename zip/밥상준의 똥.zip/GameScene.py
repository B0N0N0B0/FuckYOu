import pygame,pyautogui,subprocess,math,random,sys,os

import Choice

# _type = Choice.test()
pygame.init()

Gamescreenwidth = 1920*2  # 가로 크기
Gamescreenheight = 1080*2  # 세로 크기
Gamescreen = pygame.display.set_mode((Gamescreenwidth, Gamescreenheight))

# FPS
clock = pygame.time.Clock()

# 화면 타이틀 설정
pygame.display.set_caption("An Exact Angle")

# 배경 이미지 불러오기
Gamescene = pygame.image.load("./Pictures/etc/gameboard.png")

# 폰트 정의
game_font = pygame.font.Font(None, 40)  # 폰트 객체 생성(폰트, 크기)

# 총 시간
total_time = 10

# 시작 시간
start_ticks = pygame.time.get_ticks()  # 현재 tick을 받아옴





# 사용법

# image["원하는 이미지 이름"].image -> 이미지 로딩
# image["원하는 이미지 이름"].type  -> 벽, Team_1 유닛, Team_2 유닛 인지 알려줌
# image["원하는 이미지 이름"].width -> 이미지 가로 길이
# image["원하는 이미지 이름"].height -> 이미지 높이
# image["원하는 이미지 이름"].Xpos  -> 이미지 x좌표
# image["원하는 이미지 이름"].Ypos  -> 이미지 y좌표
# image["원하는 이미지 이름"].IsCreated -> 이미지 생성 여부 변수
# image["원하는 이미지 이름"].angle -> 뭐하는 놈인진 모르겠으나 니놈이 정해놓은 뭐시기_angle 임


# ImageLoad 클래스 사용법

# 이미지변수 이름 = ImageLoad(
#                             파일이름,
#                             x좌표,
#                             y좌표,
#                             타입
#                             )
# 이중 타입은 0,1,2 3가지가 있음.
# 0 : 벽
# 1 : 팀1
# 2 : 팀2
# 여기서 정한 타입은 image["원하는 이미지 이름"].type 으로 확인 가능함.


# ImageLoad , MadeBy B0N0N0B0
image = dict()  # image라는 변수를 딕셔너리로 정의

image_list_Team_1 = os.listdir("./Pictures/Team_1")  # image_list_Team_1라는 변수를 Team_1 폴더 속 파일 목록에서 리스트를 만듦
image_list_Team_2 = os.listdir("./Pictures/Team_2")  # image_list_Team_2라는 변수를 Team_2 폴더 속 파일 목록에서 리스트를 만듦
image_list = image_list_Team_1 + image_list_Team_2

class ImageLoad:
    def __init__(self,path,Xpos,Ypos,cond): # cond ) 0 : wall , 1 : Team 1, 2 : Team 2  /  path는 파일 이름
        if cond == 0:
            self.image = pygame.image.load("./Pictures/walls/" + path)  # 이미지 로드 경로를 Pictures/walls 안에 있는 path 이미지로 로드
            self.type = "wall"
        if cond == 1:
            self.image = pygame.image.load("./Pictures/Team_1/" + path)  # 이미지 로드 경로를 Pictures/Team_1 안에 있는 path 이미지로 로드
            self.angle = math.radians(45)
            self.type = "unit.Team_1"
        if cond == 2:
            self.image = pygame.image.load("./Pictures/Team_2/" + path)  # 이미지 로드 경로를 Pictures/Team_2 안에 있는 path 이미지로 로드
            self.angle = math.radians(45)
            self.type = "unit.Team_2"
        
        size = self.image.get_rect().size
        self.width = size[0]
        self.height = size[1]
        self.Xpos = Xpos
        self.Ypos = Ypos
        self.IsCreated = False

image["Wall_1"] = ImageLoad("wall.PNG",
                            Gamescreenwidth/4,
                            Gamescreenheight/5,
                            0)

image["Wall_2"] = ImageLoad("wall2.PNG",
                            Gamescreenwidth-400,
                            Gamescreenheight-300,
                            0)

image["Wall_3"] = ImageLoad("wall3.PNG",
                            Gamescreenwidth-400,
                            Gamescreenheight-475,
                            0)

for img in image_list_Team_1:
    image[img] = ImageLoad(img,
                           100,
                           890,
                           1)

for img in image_list_Team_2:
    image[img] = ImageLoad(img,
                           10,
                           800,
                           2)
# def dragfunction(self):
#     if self.Xpos <= event.pos[0] <= self.Xpos + self.width \
#         and self.Ypos <= event.pos[1] <= self.Ypos + self.height:
#         isdrag = True
#         drag_startpos = event.pos

# 이 아래부터 ''' 으로 묶은 코드를 위 처럼 요약한거. 알아서 잘 해보셈 ㅅㄱ

'''

# 벽 이미지 불러오기
Wall_1 = pygame.image.load("./Pictures/wall.PNG")

Wall_1_size = Wall_1.get_rect().size
Wall_1_width = Wall_1_size[0]
Wall_1_height = Wall_1_size[1]
Wall_1_Xpos = Gamescreenwidth / 4  # Gamescreenwidth의 4분의 1 
Wall_1_Ypos = Gamescreenheight / 5  # Gamescreenwidth의 5분의 1 

Wall_2 = pygame.image.load("./Pictures/wall2.PNG")

Wall_2_size = Wall_2.get_rect().size
Wall_2_width = Wall_2_size[0]
Wall_2_height = Wall_2_size[1]
Wall_2_Xpos = Gamescreenwidth - 400  # Gamescreenwidth에서 400을 뺀 값 
Wall_2_Ypos = Gamescreenheight - 300  # Gamescreenwidth에서 300을 뺀 값 

Wall_3 = pygame.image.load("./Pictures/wall3.PNG")

Wall_3_size = Wall_3.get_rect().size
Wall_3_width = Wall_3_size[0]
Wall_3_height = Wall_3_size[1]
Wall_3_Xpos = Gamescreenwidth - 400  # Gamescreenwidth에서 400을 뺀 값
Wall_3_Ypos = Gamescreenheight - 475  # Gamescreenwidth에서 475을 뺀 값 






# 스프라이트(캐릭터) 불러오기
start_x_pos = 100
start_y_pos = 890
character_angle = random.uniform(0, 2 * math.pi)

#--------------------
warrior = pygame.image.load("./Pictures/병사.png")   # 병사

warrior_size = warrior.get_rect().size
warrior_width = warrior_size[0]
warrior_height = warrior_size[1]
warrior_angle = math.radians(45)  # 45도의 각도로 이동 시작

warrior_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
warrior_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

warrior_created = False

warrior_rect = warrior.get_rect()

#--------------------------------------------------------
bomb = pygame.image.load("./Pictures/폭탄병.png")  # 폭탄병

bomb_size = bomb.get_rect().size
bomb_width = bomb_size[0]
bomb_height = bomb_size[1]
bomb_angle = math.radians(45)  # 45도의 각도로 이동 시작

bomb_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
bomb_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

bomb_created = False

bomb_rect = bomb.get_rect()

#--------------------------------------------------
shield = pygame.image.load("./Pictures/방어병.png")  # 방어병

shield_size = shield.get_rect().size
shield_width = shield_size[0]
shield_height = shield_size[1]
shield_angle = math.radians(45)  # 45도의 각도로 이동 시작

shield_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
shield_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

shield_created = False

shield_rect = shield.get_rect()

#------------------------------------------------------
rush = pygame.image.load("./Pictures/돌격병.png")  # 돌격병

rush_size = rush.get_rect().size
rush_width = rush_size[0]
rush_height = rush_size[1]
rush_angle = math.radians(45)  # 45도의 각도로 이동 시작

rush_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
rush_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

rush_created = False

rush_rect = rush.get_rect()

#--------------------------------------------------
doctor = pygame.image.load("./Pictures/의무관.png")  # 의무관

doctor_size = doctor.get_rect().size
doctor_width = doctor_size[0]
doctor_height = doctor_size[1]
doctor_angle = math.radians(45)  # 45도의 각도로 이동 시작

doctor_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
doctor_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

doctor_created = False

doctor_rect = doctor.get_rect()

#------------------------------------------------------
engineer = pygame.image.load("./Pictures/기술자.png")  # 기술자

engineer_size = engineer.get_rect().size
engineer_width = engineer_size[0]
engineer_height = engineer_size[1]
engineer_angle = math.radians(45)  # 45도의 각도로 이동 시작

engineer_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
engineer_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

engineer_created = False

engineer_rect = engineer.get_rect()

#----------------------------------------------------------
king = pygame.image.load("./Pictures/왕.png")  # 왕

king_size = king.get_rect().size
king_width = king_size[0]
king_height = king_size[1]
king_angle = math.radians(45)  # 45도의 각도로 이동 시작

king_x_pos = 100  # 화면 가로 크기의 가장 왼쪽에서 10을 더한 곳에 위치
king_y_pos = 890 # 화면 세로 크기의 가장 아래쪽에서 10을 뺀 곳에 위치

king_created = False

king_rect = king.get_rect()




# 상대편 스프라이트(캐릭터) 불러오기
another_start_xpos = 10
another_start_ypos = 800

#---------------------
ano_warrior = pygame.image.load("./Pictures/병사2.png")

ano_warrior_size = ano_warrior.get_rect().size
ano_warrior_width = ano_warrior_size[0]
ano_warrior_height = ano_warrior_size[1]
ano_warrior_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_warrior_xpos = 10
ano_warrior_ypos = 800

ano_warrior_created = False

ano_warrior_rect = ano_warrior.get_rect()

#------------------------------------------------------------
ano_bomb = pygame.image.load("./Pictures/폭탄병2.png")

ano_bomb_size = ano_bomb.get_rect().size
ano_bomb_width = ano_bomb_size[0]
ano_bomb_height = ano_bomb_size[1]
ano_bomb_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_bomb_xpos = 10
ano_bomb_ypos = 800

ano_bomb_created = False

ano_bomb_rect = ano_bomb.get_rect()

#-------------------------------------------------
ano_shield = pygame.image.load("./Pictures/방어병2.png")

ano_shield_size = ano_shield.get_rect().size
ano_shield_width = ano_shield_size[0]
ano_shield_height = ano_shield_size[1]
ano_shield_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_shield_xpos = 10
ano_shield_ypos = 800

ano_shield_created = False

ano_shield_rect = ano_shield.get_rect()

#----------------------------------
ano_rush = pygame.image.load("./Pictures/돌격병2.png")

ano_rush_size = ano_rush.get_rect().size
ano_rush_width = ano_rush_size[0]
ano_rush_height = ano_rush_size[1]
ano_rush_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_rush_xpos = 10
ano_rush_ypos = 800

ano_rush_created = False

ano_rush_rect = ano_rush.get_rect()

#---------------------------------------
ano_doctor = pygame.image.load("./Pictures/의무관2.png")

ano_doctor_size = ano_doctor.get_rect().size
ano_doctor_width = ano_doctor_size[0]
ano_doctor_height = ano_doctor_size[1]
ano_doctor_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_doctor_xpos = 10
ano_doctor_ypos = 800

ano_doctor_created = False

ano_doctor_rect = ano_doctor.get_rect()

#----------------------------------------------------------
ano_engineer = pygame.image.load("./Pictures/기술자2.png")

ano_engineer_size = ano_engineer.get_rect().size
ano_engineer_width = ano_engineer_size[0]
ano_engineer_height = ano_engineer_size[1]
ano_engineer_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_engineer_xpos = 10
ano_engineer_ypos = 800

ano_engineer_created = False

ano_engineer_rect = ano_engineer.get_rect()

#----------------------------------------------
ano_king = pygame.image.load("./Pictures/왕2.png")

ano_king_size = ano_king.get_rect().size
ano_king_width = ano_king_size[0]
ano_king_height = ano_king_size[1]
ano_king_angle = math.radians(45)  # 45도의 각도로 이동 시작

ano_king_xpos = 10
ano_king_ypos = 800

ano_king_created = False

ano_king_rect = ano_king.get_rect()

'''

# 파랑팀
isdrag_1 = False  # 마우스 커서로 드래그하는지 확인하는 변수
drag_SP_1 = None
character_1 = [image[img] for img in image_list_Team_1]
velocity_1 = [0, 0]
drag_force_1 = 20  # 움직일 때 받는 힘
drag_friction_1 = 0.05  # 움직일 때 받는 마찰

# 빨강팀
isdrag_2 = False  # 마우스 커서로 드래그하는지 확인하는 변수
drag_SP_2 = None
character_2 = [image[img] for img in image_list_Team_2]
velocity_2 = [0, 0]
drag_force_2 = 20  # 움직일 때 받는 힘
drag_friction_2 = 0.05  # 움직일 때 받는 마찰

ep = None
ip = None

delta_pos = list()

# # 충돌한 물체의 속도와 충돌 각도
cs = 17.5

ca = random.uniform(0, 2 * math.pi)  # 충돌 각도를 라디안으로 변경

new_velocity_x = cs * math.cos(ca)
new_velocity_y = ca * math.sin(ca)


# # 객체 클래스 정의
# class GameObject:
#     def __init__(self, img, x, y):
#         self.image = image[img].image
#         self.rect = self.image.get_rect()
#         self.rect.topleft = (x, y)

# # # 객체 생성
# bomb_chr = GameObject(bomb, bomb_x_pos, bomb_y_pos)
# ano_bomb_chr = GameObject(ano_bomb, ano_bomb_xpos, ano_bomb_ypos)
# wall_1_sprite = GameObject(Wall_1, Wall_1_Xpos, Wall_1_Ypos)
# wall_2_sprite = GameObject(Wall_2, Wall_2_Xpos, Wall_2_Ypos)
# wall_3_sprite = GameObject(Wall_3, Wall_3_Xpos, Wall_3_Ypos)

# gameobjects = [bomb_chr, wall_1_sprite, wall_2_sprite, wall_3_sprite]

# 이벤트 처리
running = True  # 게임이 진행 중인가를 확인하는 변수


# scripts = ["C:/Users/shk/Pictures/Choice.py", "C:/Users/shk/Pictures/Another Choice.py"]
# current_script_index = 0
# maxscript = 10  # 최대 실행 횟수

# def run_script(scripts_path):
#     subprocess.run(["python", str(scripts_path)], shell=True)
def Choicing(team : int()):
    global _type_1 , _type_2
    if team==1:
        _type_1 = Choice.Team(Team=1) 
        
        if _type_1 == 1:
            image["warrior.png"].IsCreated = True

        if _type_1 == 2:
            image["warrior.png"].IsCreated = True
        
        if _type_1 == 3:
            image["shield.png"].IsCreated = True
        
        if _type_1 == 4:
            image["rush.png"].IsCreated = True
        
        if _type_1 == 5:
            image["doctor.png"].IsCreated = True
        
        if _type_1 == 6:
            image["engineer.png"].IsCreated = True

        if _type_1 == 7:
            image["king.png"].IsCreated = True

    if team==2: 
        _type_2 = Choice.Team(Team=2)

        if _type_2 == 1:
            image["ano_warrior.png"].IsCreated = True

        if _type_2 == 2:
            image["ano_bonb.png"].IsCreated = True

        if _type_2 == 3:
            image["ano_shield.png"].IsCreated = True

        if _type_2 == 4:
            image["ano_rush.png"].IsCreated = True

        if _type_2 == 5:
            image["ano_doctor.png"].IsCreated = True

        if _type_2 == 6:
            image["ano_engineer.png"].IsCreated = True

        if _type_2 == 7:
            image["ano_king.png"].IsCreated = True
def img_vel():
    global image
    if _type_1 == 1:
        image["warrior.png"].Xpos += velocity_1[0]
        image["warrior.png"].Ypos += velocity_1[1]

    if _type_1 == 2:
        image["bomb.png"].Xpos += velocity_1[0]
        image["bomb.png"].Ypos += velocity_1[1]
    
    if _type_1 == 3:
        image["shield.png"].Xpos += velocity_1[0]
        image["shield.png"].Ypos += velocity_1[1]
    
    if _type_1 == 4:
        image["rush.png"].Xpos += velocity_1[0]
        image["rush.png"].Ypos += velocity_1[1]
    
    if _type_1 == 5:
        image["doctor.png"].Xpos += velocity_1[0]
        image["doctor.png"].Ypos += velocity_1[1]
    
    if _type_1 == 6:
        image["engineer.png"].Xpos += velocity_1[0]
        image["engineer.png"].Ypos += velocity_1[1]

    if _type_1 == 7:
        image["king.png"].Xpos += velocity_1[0]
        image["king.png"].Ypos += velocity_1[1]

    if _type_2 == 1:
        image["ano_warrior.png"].Xpos += velocity_2[0]
        image["ano_warrior.png"].Ypos += velocity_2[1]

    if _type_2 == 2:
        image["ano_bomb.png"].Xpos += velocity_2[0]
        image["ano_bomb.png"].Ypos += velocity_2[1]
    
    if _type_2 == 3:
        image["ano_shield.png"].Xpos += velocity_2[0]
        image["ano_shield.png"].Ypos += velocity_2[1]
    
    if _type_2 == 4:
        image["ano_rush.png"].Xpos += velocity_2[0]
        image["ano_rush.png"].Ypos += velocity_2[1]
    
    if _type_2 == 5:
        image["ano_doctor.png"].Xpos += velocity_2[0]
        image["ano_doctor.png"].Ypos += velocity_2[1]
    
    if _type_2 == 6:
        image["ano_engineer.png"].Xpos += velocity_2[0]
        image["ano_engineer.png"].Ypos += velocity_2[1]

    if _type_2 == 7:
        image["ano_king.png"].Xpos = velocity_2[0]
        image["ano_king.png"].Ypos = velocity_2[1]
def dragfunction(img : None ,type : int(),event : None):
    global isdrag_1,isdrag_2,drag_SP_1,drag_SP_2,ep,ip
    if image[img].Xpos <= event.pos[0] <= image[img].Xpos + image[img].width \
        and image[img].Ypos <= event.pos[1] <= image[img].Ypos + image[img].height:
        # click_chr = img

        if type==1 : isdrag_1 = True ; drag_SP_1 = event.pos
        else : isdrag_2 = True ; drag_SP_2 = event.pos
        
        ep = event.pos
        ip = [image[img].Xpos,image[img].Ypos]

def blit(img : None) : Gamescreen.blit(image[img].image,(image[img].Xpos,image[img].Ypos))

Choicing(team=1)
Choicing(team=2)
index = 0
while running:
    clock.tick(80)  # 게임 화면의 초당 프레임 수를 설정
    
    #print("fps : " + str(clock.get_fps()))

#     isOpenpy = False  # Choice.py가 열려있는가?
#     isOpeningpy = False  # Another Choice.py가 열려있는가?



    for event in pygame.event.get():  # 어떤 이벤트가 발생하였는가?

        if event.type == pygame.QUIT:  # 창이 닫히는 이벤트가 발생하였는가?
            running = False  # 게임이 진행중이 아님

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:  # esc를 눌렀을 때 게임을 종료시키기
                running = False
            if event.key == pygame.K_1:
                index += 1

            '''
            if event.key == pygame.K_q:  # q키를 누르고 병사가 소환되지 않았을 때
                image["warrior.png"].IsCreated = not image["warrior.png"].IsCreated
            
            if event.key == pygame.K_w:  # w키를 누르고 폭탄병이 소환되지 않았을 때
                image["warrior.png"].IsCreated = not image["warrior.png"].IsCreated
                
            if event.key == pygame.K_e:  # e키를 누르고 방어병이 소환되지 않았을 때
                image["shield.png"].IsCreated = not image["shield.png"].IsCreated
                
            if event.key == pygame.K_r:  # r키를 누르고 돌격병이 소환되지 않았을 때
                image["rush.png"].IsCreated = not image["rush.png"].IsCreated
                
            if event.key == pygame.K_a:  # a키를 누르고 의무관이 소환되지 않았을 때
                image["doctor.png"].IsCreated = not image["doctor.png"].IsCreated
                
            if event.key == pygame.K_s:  # s키를 누르고 기술자가 소환되지 않았을 때
                image["engineer.png"].IsCreated = not image["engineer.png"].IsCreated
            
            if event.key == pygame.K_d:  # d키를 누르고 왕이 소환되지 않았을 때
                image["king.png"].IsCreated = not image["king.png"].IsCreated

            if event.key == pygame.K_u:  # u키를 누르고 병사가 소환되지 않았을 때
                image["ano_warrior.png"].IsCreated = not image["ano_warrior.png"].IsCreated
            
            if event.key == pygame.K_i:  # i키를 누르고 폭탄병이 소환되지 않았을 때
                image["ano_bonb.png"].IsCreated = not image["ano_bonb.png"].IsCreated

            if event.key == pygame.K_o:  # o키를 누르고 방어병이 소환되지 않았을 때
                image["ano_shiled.png"].IsCreated = not image["ano_shiled.png"].IsCreated

            if event.key == pygame.K_p:  # p키를 누르고 돌격병이 소환되지 않았을 때
                image["ano_rush.png"].IsCreated = not image["ano_rush.png"].IsCreated

            if event.key == pygame.K_j:  # j키를 누르고 의무관이 소환되지 않았을 때
                image["ano_doctor.png"].IsCreated = not image["ano_doctor.png"].IsCreated

            if event.key == pygame.K_k:  # k키를 누르고 기술자가 소환되지 않았을 때
                image["ano_engineer.png"].IsCreated = not image["ano_engineer.png"].IsCreated

            if event.key == pygame.K_l:  # l키를 누르고 왕이 소환되지 않았을 때
                image["ano_king.png"].IsCreated = not image["ano_king.png"].IsCreated
            '''

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # 마우스 왼쪽 버튼을 누를 때
                for img in image_list_Team_1 : dragfunction(img=img,type=1,event=event)
                for img in image_list_Team_2 : dragfunction(img=img,type=2,event=event)



        elif event.type == pygame.MOUSEBUTTONUP:
            delta_pos = [event.pos[0]-ep[0],event.pos[1]-ep[1]]
            isdrag_1 = False
            isdrag_2 = False
            ep = None
        elif event.type == pygame.MOUSEMOTION:
            if isdrag_1:
                image["bomb.png"].Xpos = -ep[0]+event.pos[0] + ip[0]
                image["bomb.png"].Ypos = -ep[1]+event.pos[1] + ip[1]
            if isdrag_2:
                pass
        
        
        elif event.type == pygame.MOUSEMOTION:  # 드래그 이벤트 처리
            if isdrag_1:
                isOpenpy_1 = True
                # 드래그한 방향과 거리를 계산하여 velocity 설정
                distance = max(1, pygame.math.Vector2(delta_pos[0], delta_pos[1]).length())
                velocity_1 = [drag_force_1 * delta_pos[0] / distance, drag_force_1 * delta_pos[1] / distance]
            
            
            if isdrag_2:
                isOpenpy_2 = True
                # 드래그한 방향과 거리를 계산하여 velocity 설정
                distance = max(1, pygame.math.Vector2(delta_pos[0], delta_pos[1]).length())
                velocity_2 = [drag_force_2 * delta_pos[0] / distance, drag_force_2 * delta_pos[1] / distance]

        Gamescreen.fill((0,0,0))
        blit(img="bomb.png")
        pygame.display.flip()    

    img_vel()

    velocity_1 = [int(velocity_1[0]*drag_friction_1),int(velocity_1[1]*drag_friction_1)]
    velocity_2 = [int(velocity_2[0]*drag_friction_2),int(velocity_2[1]*drag_friction_2)]
'''
                # 파랑팀
#                 if warrior_x_pos <= event.pos[0] <= warrior_x_pos + warrior_width \
#                     and warrior_y_pos <= event.pos[1] <= warrior_y_pos + warrior_height:
#                     isdrag = True
#                     drag_startpos = event.pos
#                 if bomb_x_pos <= event.pos[0] <= bomb_x_pos + bomb_width \
#                     and bomb_y_pos <= event.pos[1] <= bomb_y_pos + bomb_height:
#                     isdrag = True
#                     drag_startpos = event.pos
#                 if shield_x_pos <= event.pos[0] <= shield_x_pos + shield_width \
#                     and shield_y_pos <= event.pos[1] <= shield_y_pos + shield_height:
#                     isdrag = True
#                     drag_startpos = event.pos
#                 if rush_x_pos <= event.pos[0] <= rush_x_pos + rush_width \
#                     and rush_y_pos <= event.pos[1] <= rush_y_pos + rush_height:
#                     isdrag = True
#                     drag_startpos = event.pos
#                 if doctor_x_pos <= event.pos[0] <= doctor_x_pos + doctor_width \
#                     and doctor_y_pos <= event.pos[1] <= doctor_y_pos + doctor_height:
#                     isdrag = True
#                     drag_startpos = event.pos
#                 if engineer_x_pos <= event.pos[0] <= engineer_x_pos + engineer_width \
#                     and engineer_y_pos <= event.pos[1] <= engineer_y_pos + engineer_height:
#                     isdrag = True
#                     drag_startpos = event.pos
#                 if king_x_pos <= event.pos[0] <= king_x_pos + king_width \
#                     and king_y_pos <= event.pos[1] <= king_y_pos + king_height:
#                     isdrag = True
#                     drag_startpos = event.pos


#                 # 빨강팀
#                 if ano_warrior_xpos <= event.pos[0] <= ano_warrior_xpos + ano_warrior_width \
#                     and ano_warrior_ypos <= event.pos[1] <= ano_warrior_ypos + ano_warrior_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
#                 if ano_bomb_xpos <= event.pos[0] <= ano_bomb_xpos + ano_bomb_width \
#                     and ano_bomb_ypos <= event.pos[1] <= ano_bomb_ypos + ano_bomb_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
#                 if ano_shield_xpos <= event.pos[0] <= ano_shield_xpos + ano_shield_width \
#                     and ano_shield_ypos <= event.pos[1] <= ano_shield_ypos + ano_shield_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
#                 if ano_rush_xpos <= event.pos[0] <= ano_rush_xpos + ano_rush_width \
#                     and ano_rush_ypos <= event.pos[1] <= ano_rush_ypos + ano_rush_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
#                 if ano_doctor_xpos <= event.pos[0] <= ano_doctor_xpos + ano_doctor_width \
#                     and ano_doctor_ypos <= event.pos[1] <= ano_doctor_ypos + ano_doctor_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
#                 if ano_engineer_xpos <= event.pos[0] <= ano_engineer_xpos + ano_engineer_width \
#                     and ano_engineer_ypos <= event.pos[1] <= ano_engineer_ypos + ano_engineer_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
#                 if ano_king_xpos <= event.pos[0] <= ano_king_xpos + ano_king_width \
#                     and ano_king_ypos <= event.pos[1] <= ano_king_ypos + ano_king_height:
#                     isdragging = True
#                     dragging_startpos = event.pos
'''
                
        # elif event.type == pygame.MOUSEBUTTONUP:
        #     if event.button == 1:  # 마우스 왼쪽 버튼을 떼었을 때
        #         isdrag_1,isdrag_2 = False

        #         if isdrag_1 == False and isOpeningpy and not isOpenpy:
        #             subprocess.Popen(["python", "./Pictures/Another Choice.py"])
        #             isOpeningpy = False
                    

        #         if isdrag_2 == False and not isOpeningpy and isOpenpy:
        #             subprocess.Popen(["python", ".Pictures/Choice.py"])
        #             isOpenpy = False

                #scripts_path = scripts[current_script_index]   
                #current_script_index = (current_script_index + 1) % len(scripts)
                #run_script(scripts_path)

    
               
    # 스프라이트 이동

'''
    # 파랑팀
#     warrior_x_pos += velocity[0]
#     warrior_y_pos += velocity[1]

#     bomb_x_pos += velocity[0]
#     bomb_y_pos += velocity[1]

#     shield_x_pos += velocity[0]
#     shield_y_pos += velocity[1]

#     rush_x_pos += velocity[0]
#     rush_y_pos += velocity[1]

#     doctor_x_pos += velocity[0]
#     doctor_y_pos += velocity[1]

#     engineer_x_pos += velocity[0]
#     engineer_y_pos += velocity[1]

#     king_x_pos += velocity[0]
#     king_y_pos += velocity[1]

#     # 빨강팀
#     ano_warrior_xpos += ano_velocity[0]
#     ano_warrior_ypos += ano_velocity[1]

#     ano_bomb_xpos += ano_velocity[0]
#     ano_bomb_ypos += ano_velocity[1]

#     ano_shield_xpos += ano_velocity[0]
#     ano_shield_ypos += ano_velocity[1]

#     ano_rush_xpos += ano_velocity[0]
#     ano_rush_ypos += ano_velocity[1]

#     ano_doctor_xpos += ano_velocity[0]
#     ano_doctor_ypos += ano_velocity[1]

#     ano_engineer_xpos += ano_velocity[0]
#     ano_engineer_ypos += ano_velocity[1]

#     ano_king_xpos += ano_velocity[0]
#     ano_king_ypos += ano_velocity[1]
    
#     # 서서히 멈추도록 velocity를 감소시킴

#     ano_velocity[0] *= (1 - dragging_friction)
#     ano_velocity[1] *= (1 - dragging_friction)
'''

    
#     # 캐릭터의 이동 방향 벡터 계산
#     #character_move = pygame.math.Vector2(character_x_pos + 100 / 2, character_y_pos + 100 / 2)
#     #another_chr_move = pygame.math.Vector2(another_chr_xpos + 100 / 2, another_chr_ypos + 100 / 2)


#     # 화면 끝에 닿으면 튕기기
#     # 가로벽에 닿았을 때
    if character_x_pos < 0 or character_x_pos > Gamescreenwidth - 100:
        velocity_1 = [int(velocity_1[0]*drag_friction_1),int(velocity_1[1]*drag_friction_1)]
    # 세로벽에 닿았을 때
    if character_y_pos < 0 or character_y_pos > Gamescreenheight - 100:
        character_angle = image[+ing]
    
    # 해야될 것 : 가로벽, 세로벽 끝에 닿았을 때 튕겨나가게 하는 코드 작성하기. 
    # 이미지 크기 고려해서 튕겨나가는 코드 작성


#     wall_1_rect = Wall_1.get_rect()
#     wall_1_rect.left = Wall_1_Xpos
#     wall_1_rect.top = Wall_1_Ypos

#     wall_2_rect = Wall_2.get_rect()
#     wall_2_rect.left = Wall_2_Xpos
#     wall_2_rect.top = Wall_2_Ypos

#     wall_3_rect = Wall_3.get_rect()
#     wall_3_rect.left = Wall_3_Xpos
#     wall_3_rect.top = Wall_3_Ypos
    
#     # 충돌 체크
#     # 파랑팀
#     warrior_rect = warrior.get_rect()
#     warrior_rect.left = warrior_x_pos
#     warrior_rect.top = warrior_y_pos

#     bomb_rect = bomb.get_rect()
#     bomb_rect.left = bomb_x_pos
#     bomb_rect.top = bomb_y_pos

#     shield_rect = shield.get_rect()
#     shield_rect.left = shield_x_pos
#     shield_rect.top = shield_y_pos

#     #rush_rect = rush.get_rect()
#     #rush_rect.left = rush_x_pos
#     #rush_rect.top = rush_y_pos

#     doctor_rect = doctor.get_rect()
#     doctor_rect.left = doctor_x_pos
#     doctor_rect.top = doctor_y_pos

#     engineer_rect = engineer.get_rect()
#     engineer_rect.left = engineer_x_pos
#     engineer_rect.top = engineer_y_pos

#     king_rect = king.get_rect()
#     king_rect.left = king_x_pos
#     king_rect.top = king_y_pos

#     # 빨강팀
#     ano_warrior_rect = ano_warrior.get_rect()
#     ano_warrior_rect.left = ano_warrior_xpos
#     ano_warrior_rect.top = ano_warrior_ypos

#     ano_bomb_rect = ano_bomb.get_rect()
#     ano_bomb_rect.left = ano_bomb_xpos
#     ano_bomb_rect.top = ano_bomb_ypos

#     ano_shield_rect = ano_shield.get_rect()
#     ano_shield_rect.left = ano_shield_xpos
#     ano_shield_rect.top = ano_shield_ypos

#     ano_rush_rect = ano_rush.get_rect()
#     ano_rush_rect.left = ano_rush_xpos
#     ano_rush_rect.top = ano_rush_ypos

#     ano_doctor_rect = ano_doctor.get_rect()
#     ano_doctor_rect.left = ano_doctor_xpos
#     ano_doctor_rect.top = ano_doctor_ypos

#     ano_engineer_rect = engineer.get_rect()
#     ano_engineer_rect.left = ano_engineer_xpos
#     ano_engineer_rect.top = ano_engineer_ypos

#     ano_king_rect = ano_king.get_rect()
#     ano_king_rect.left = ano_king_xpos
#     ano_king_rect.top = ano_king_ypos



#     # 충돌 체크
#     # 파랑팀
#     if warrior_rect.colliderect(wall_1_rect) or warrior_rect.colliderect(wall_2_rect) or warrior_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         warrior_angle = new_angle
#         velocity = [new_velocity_x, new_velocity_y]

    
#     # 충돌 체크
#     collided_obj = []

#     for obj in gameobjects:
#         if bomb_rect.colliderect(obj.rect) and obj != bomb_chr:
#             collided_obj.append(obj)
#     for obj in collided_obj:
#         gameobjects.remove(obj)
#     # 객체를 삭제한 후에 gameobjects 리스트에 업데이트해야 함
#     for obj in gameobjects:
#         obj_rect = obj.rect
#         obj.rect = obj.image.get_rect()
#         obj.rect.topleft = obj.rect.topleft
    

#     if shield_rect.colliderect(wall_1_rect) or shield_rect.colliderect(wall_2_rect) or shield_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         velocity = [0, 0]
    

#     #if rush_rect.colliderect(wall_1_rect) or rush_rect.colliderect(wall_2_rect) or rush_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         #rush_angle = new_angle
#         #velocity = [new_velocity_x, new_velocity_y]


#     if doctor_rect.colliderect(wall_1_rect) or doctor_rect.colliderect(wall_2_rect) or doctor_rect.colliderect(wall_3_rect): 
#         #print("충돌했어요")
#         doctor_angle = new_angle
#         velocity = [new_velocity_x, new_velocity_y]
    

#     if engineer_rect.colliderect(wall_1_rect) or engineer_rect.colliderect(wall_2_rect) or engineer_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         engineer_angle = new_angle
#         velocity = [new_velocity_x, new_velocity_y]
    

#     if king_rect.colliderect(wall_1_rect) or king_rect.colliderect(wall_2_rect) or king_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         king_angle = new_angle
#         velocity = [new_velocity_x, new_velocity_y]
    


#     # 빨강팀
#     if ano_warrior_rect.colliderect(wall_1_rect) or ano_warrior_rect.colliderect(wall_2_rect) or ano_warrior_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         ano_warrior_angle = new_angle
#         ano_velocity = [new_velocity_x, new_velocity_y]


#     # 충돌 체크
#     collided_obj = []

#     for obj in gameobjects:
#         if bomb_rect.colliderect(obj.rect) and obj != bomb_chr:
#             collided_obj.append(obj)
#     for obj in collided_obj:
#         gameobjects.remove(obj)
#     # 객체를 삭제한 후에 gameobjects 리스트에 업데이트해야 함
#     for obj in gameobjects:
#         obj_rect = obj.rect
#         obj.rect = obj.image.get_rect()
#         obj.rect.topleft = obj.rect.topleft
    


#     if ano_shield_rect.colliderect(wall_1_rect) or ano_shield_rect.colliderect(wall_2_rect) or ano_shield_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         ano_velocity = [0, 0]


#     if ano_rush_rect.colliderect(wall_1_rect) or ano_rush_rect.colliderect(wall_2_rect) or ano_rush_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         ano_rush_angle = new_angle
#         ano_velocity = [new_velocity_x, new_velocity_y]


#     if ano_doctor_rect.colliderect(wall_1_rect) or ano_doctor_rect.colliderect(wall_2_rect) or ano_doctor_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         ano_doctor_angle = new_angle
#         ano_velocity = [new_velocity_x, new_velocity_y]


#     if ano_engineer_rect.colliderect(wall_1_rect) or ano_engineer_rect.colliderect(wall_2_rect) or ano_engineer_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         ano_engineer_angle = new_angle
#         ano_velocity = [new_velocity_x, new_velocity_y]


#     if ano_king_rect.colliderect(wall_1_rect) or ano_king_rect.colliderect(wall_2_rect) or ano_king_rect.colliderect(wall_3_rect):
#         #print("충돌했어요")
#         ano_king_angle = new_angle
#         ano_velocity = [new_velocity_x, new_velocity_y]

#     '''
#     # 화면 경계를 벗어나지 않게 하기
#     if character_x_pos - character_width < 0:
#         character_x_pos = character_width
#     elif character_x_pos + character_width > Gamescreenwidth:
#         character_x_pos = Gamescreenwidth - character_width

#     if character_y_pos - character_height < 0:
#         character_y_pos = character_height
#     elif character_y_pos + character_height > Gamescreenheight:
#         character_y_pos = Gamescreenheight - character_height
#     '''

    # Gamescreen.blit(Gamescene, (0, 0))

    
#     Gamescreen.blit(Wall_1, (Wall_1_Xpos, Wall_1_Ypos))  # 첫 번째 벽 그리기
#     Gamescreen.blit(Wall_2, (Wall_2_Xpos, Wall_2_Ypos))  # 두 번째 벽 그리기
#     Gamescreen.blit(Wall_3, (Wall_3_Xpos, Wall_3_Ypos))  # 세 번째 벽 그리기

#     if warrior_created:
#         Gamescreen.blit(warrior, (warrior_x_pos, warrior_y_pos))
#         pygame.display.update()

#     if bomb_created:
#         Gamescreen.blit(bomb, (bomb_x_pos, bomb_y_pos))
#         pygame.display.update()

#     if shield_created:
#         Gamescreen.blit(shield, (shield_x_pos, shield_y_pos))
#         pygame.display.update()

#     if rush_created:
#         Gamescreen.blit(rush, (rush_x_pos, rush_y_pos))
#         pygame.display.update()

#     if doctor_created:
#         Gamescreen.blit(doctor, (doctor_x_pos, doctor_y_pos))
#         pygame.display.update()

#     if engineer_created:
#         Gamescreen.blit(engineer, (engineer_x_pos, engineer_y_pos))
#         pygame.display.update()

#     if king_created:
#         Gamescreen.blit(king, (king_x_pos, king_y_pos))
#         pygame.display.update()



#     if ano_warrior_created:
#         Gamescreen.blit(ano_warrior, (ano_warrior_xpos, ano_warrior_ypos))
#         pygame.display.update()

#     if ano_bomb_created:
#         Gamescreen.blit(ano_bomb, (ano_bomb_xpos, ano_bomb_ypos))
#         pygame.display.update()

#     if ano_shield_created:
#         Gamescreen.blit(ano_shield, (ano_shield_xpos, ano_shield_ypos))
#         pygame.display.update()

#     if ano_rush_created:
#         Gamescreen.blit(ano_rush, (ano_rush_xpos, ano_rush_ypos))
#         pygame.display.update()

#     if ano_doctor_created:
#         Gamescreen.blit(ano_doctor, (ano_doctor_xpos, ano_doctor_ypos))
#         pygame.display.update()

#     if ano_engineer_created:
#         Gamescreen.blit(ano_engineer, (ano_engineer_xpos, ano_engineer_ypos))
#         pygame.display.update()

#     if ano_king_created:
#         Gamescreen.blit(ano_king, (ano_king_xpos, ano_king_ypos))
#         pygame.display.update()


#     # 타이머 집어 넣기
#     # 경과 시간 계산
#     #elapsed_time = (pygame.time.get_ticks() - start_ticks) / 1000
#     # 경과 시간(ms)을 1000으로 나누어서 초 단위로 표시

#     #timer = game_font.render(str (int (total_time - elapsed_time)), True, (0, 0, 0))
#     # 출력할 글자, True, 글자 색상
#     #Gamescreen.blit(timer, (10, 10))

#     # 만약 시간이 0 이하이면 선택지 불러오기
#     #if total_time - elapsed_time <= 0:
#         #print("타임 아웃")
    

# pygame 종료
pygame.quit()
sys.exit()
