velocity_1 = [20,10]
drag_friction_1 = 0.8
for i in range(20):
    velocity_1 = [int(velocity_1[0]*drag_friction_1),int(velocity_1[1]*drag_friction_1)]
    print(velocity_1)